#!/bin/bash          
javac peerProcess.java MessageType.java Logger.java RemotePeerInfo.java Client.java Messages.java FileHandling.java FileHandlingTest1.java Handler.java